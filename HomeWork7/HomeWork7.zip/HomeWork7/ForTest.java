package HomeWork7;

public class ForTest {
    public int Plus(int a, int b) {
        return a + b;
    }

    public int Minus(int a, int b) {
        return a - b;
    }

    public int Div(int a, int b) {
        return a / b;
    }

    public String Cont(String a, String b) {
        return a + b;
    }

    public String ChngChar(String a, char oldC, char newC) {
        return a.replace(oldC, newC);
    }
}
